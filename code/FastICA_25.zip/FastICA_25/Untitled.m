a=number('please enter a number a=');
b=number('please enter a number b=');
a+b=
