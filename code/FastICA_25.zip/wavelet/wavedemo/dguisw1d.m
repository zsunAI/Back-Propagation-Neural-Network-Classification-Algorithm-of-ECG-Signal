function varargout = dguisw1d(varargin)
%DGUISW1D Shows 1-D SWT de-noising wavelet GUI tools in the Wavelet Toolbox.
%
% This is a slideshow file for use with wshowdrv.m
% To see it run, type 'wshowdrv dguisw1d', 
%   
%   See also SWT, ISWT.

%   M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 05-May-99.
%   Last Revision: 23-May-2012.
%   Copyright 1995-2012 The MathWorks, Inc.

% Initialization and Local functions if necessary.
if nargin>0
	action = varargin{1};
	switch action
	  case 'auto'    , wshowdrv('#autoMode',mfilename,'close');
	  case 'gr_auto' , wshowdrv('#gr_autoMode',mfilename,'close');

	  case 'getFigParam'
		  figName  = getWavMSG('Wavelet:wavedemoMSGRF:DGUI_SW1D');
		  showType = 'command';
		  varargout = {figName,showType};
		  
	  case 'slidePROC_Init'
		  figHandle = varargin{2};
		  localPARAM = wtbxappdata('get',figHandle,'localPARAM');
		  if ~isempty(localPARAM)
			  active_fig = localPARAM{1};
			  delete(active_fig);
			  wtbxappdata('del',figHandle,'localPARAM');
		  end
		  
	  case 'slidePROC'
		  [figHandle,idxSlide]  = deal(varargin{2:end});
		  localPARAM = wtbxappdata('get',figHandle,'localPARAM');
		  if isempty(localPARAM)
			  active_fig = sw1dtool;
			  wenamngr('Inactive',active_fig);
			  localPARAM = {active_fig};
			  wtbxappdata('set',figHandle,'localPARAM',localPARAM);
			  wshowdrv('#modify_cbClose',figHandle,active_fig,'sw1dtool');
		  else
			  active_fig = deal(localPARAM{:});
		  end
		  numDEM = idxSlide-1;
		  demoSET = {...
				  'noisbloc' , 'haar', 5 , {} ; ...
				  'noisbump' , 'sym4', 5 , {} ; ...
				  'heavysin' , 'sym8', 5 , {} ; ...
				  'noisdopp' , 'sym4', 5 , {} ; ...
				  'noischir' , 'db1' , 5 , {} ; ...
				  'noismima' , 'db3' , 6 , {} ; ...
				  'noisbloc' , 'haar', 5 , {'penallo'}; ...
				  'nblocr1'  , 'haar', 5 , {3} ; ...
				  'nblocr2'  , 'haar', 5 , {3} ; ...
				  'ndoppr1'  , 'haar', 5 , {3} ; ...
				  'nbumpr1'  , 'haar', 5 , {3} ; ...
				  'nbumpr2'  , 'haar', 5 , {2} ; ...
				  'nbumpr3'  , 'haar', 5 , {4} ; ...
				  'nelec'    , 'haar', 4 , {3}   ...
			  };
		  nbDEM = size(demoSET,1);
		  if ismember(numDEM,1:nbDEM)
			  paramDEM = demoSET(numDEM,:);
			  sw1dtool('demo',active_fig,paramDEM{:});
			  wenamngr('Inactive',active_fig);
		  end
	end
	return
end

if nargout<1,
  wshowdrv(mfilename)
else
  idx = 0;	slide(1).code = {}; slide(1).text = {};
  
  %========== Slide 1 ==========
  idx = idx+1;
  slide(idx).code = {
	  'figHandle = gcf;'
	  [mfilename ,'(''slidePROC_Init'',figHandle);']
	  '' };
  
  %========== Slide 2 to 15 ==========
  for idx = 2:15
	  slide(idx).code = {
		  [mfilename ,'(''slidePROC'',figHandle,', int2str(idx), ');']
	  };
  end
  
  varargout{1} = slide;
  
end

