% WPTREE/LOADOBJ   load �ɂ��R�[��

%   M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 29-Sep-2001.
%   Copyright 1995-2003 The MathWorks, Inc.
