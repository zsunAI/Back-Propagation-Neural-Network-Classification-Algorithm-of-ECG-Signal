function hstr = handle2str(hdl)
%HANDLE2STR Convert a handle to a string. 

%   M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 18-Apr-2013.
%   Last Revision: 04-Jul-2013.
%   Copyright 1995-2013 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2013/08/23 23:45:06 $


%###########################################################
%%%    UNDER DEVELOPMENT
%###########################################################
type = get(hdl,'type');
if isGraphicsVersion2 && isequal(type,'figure') && ...
        ~isnumeric(hdl) && isprop(hdl,'Number')
    if isequal(get(hdl,'IntegerHandle'),'on')
        hstr = int2str(hdl.Number);
    else
        hstr = sprintf('%20.15f',double(hdl.Number));
    end
else
    if size(type,1)<2
        % disp(['type = ' type])
    else
        % disp('type: '); 
        % AA = cat(1,type{:}); disp(AA);
    end
    hstr = sprintf('%20.15f',double(hdl));
end
%###########################################################
