function bool = isGraphicsVersion2
%isGraphicsVersion2 True for Graphic version 2. 

%   M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 21-Jun-2013.
%   Last Revision: 04-Jul-2013.
%   Copyright 1995-2013 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2013/08/23 23:45:07 $

try
    bool = ~matlab.graphics.internal.isGraphicsVersion1;
catch
    bool = ~isprop(0,'HideUndocumented');
end