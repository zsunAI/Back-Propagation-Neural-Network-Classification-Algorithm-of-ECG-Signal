% DW2DMNGR �@���U2�����E�F�[�u���b�g�Ɋւ����ʓI�ȊǗ��R�}���h
%   OUT1 = DW2DMNGR(OPTION,WIN_DW2DTOOL,IN3,IN4,IN5)
%
% option = 'load_img'
% option = 'load_dec'
% option = 'load_cfs'
% option = 'demo'
% option = 'save_synt'
% option = 'save_cfs'
% option = 'save_dec'
% option = 'analyze'
% option = 'synthesize'
% option = 'step2'
% option = 'view_dec'
% option = 'select'
% option = 'view_mode'
% option = 'fullsize'
% option = 'return_comp'
% option = 'return_deno'
% option = 'set_graphic'
% option = 'mode_sel'
% option = 'compile'



%   Copyright 1995-2004 The MathWorks, Inc.
