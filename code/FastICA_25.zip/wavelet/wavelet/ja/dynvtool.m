% DYNVTOOL �@�_�C�i�~�b�N�ȉ����c�[��
%   VARARGOUT = DYNVTOOL(OPTION,FIG,VARARGIN)
%
% option = 'create'
% option = 'attach' 
% option = 'init'
% option = 'go'
% option = 'stop'
% option = 'on'
% option = 'delbox'
% option = 'delline'
% option = 'nolines'
% option = 'getbox'
% option = 'fcn_w'
% option = 'close'
%
% option = 'ini_his'
% option = 'get'
% option = 'put'
% option = 'zoom+'
% option = 'zoom-'
% option = 'center'
%
% option = 'hide'
% option = 'show'
%
% option = 'wmb'
% option = 'rmb'
% option = 'handles'



%   Copyright 1995-2004 The MathWorks, Inc.
