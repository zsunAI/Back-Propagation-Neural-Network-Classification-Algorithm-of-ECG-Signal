% WHELPFUN �@�⏕�֐�
%   [OUT1,OUT2] = WHELPFUN(OPTION,IN2,IN3,IN4)



%   Copyright 1995-2004 The MathWorks, Inc.
